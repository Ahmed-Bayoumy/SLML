# SML
Surrogate Models Library: A python library for dynamic surrogates

**Version 1.0.0**

---

## License & copyright

© Ahmed H. Bayoumy 
---
## How to use SML package

After installing the `SML` package, the functions and classes of `SML` module can be imported directly to the python script as follows:

```pycon
from SML import *
```
